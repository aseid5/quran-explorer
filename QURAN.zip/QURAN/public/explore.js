document.getElementById("searchBtn").addEventListener("click", async () => {
  const keyword = document.getElementById("keywordInput").value;
  const resultsDiv = document.getElementById("results");
  resultsDiv.innerHTML = "Loading...";

  try {
    const response = await fetch(`https://api.alquran.cloud/v1/search/${keyword}/all/en.asad`);
    const data = await response.json();

    if (!data.data || data.data.count === 0) {
      resultsDiv.innerHTML = "No ayahs found.";
      return;
    }

    resultsDiv.innerHTML = "";

    data.data.matches.forEach((match) => {
      const ayahText = match.text;
      const surah = `Surah ${match.surah.name} (${match.surah.englishName})`;

      const ayahDiv = document.createElement("div");
      ayahDiv.className = "ayah";

      ayahDiv.innerHTML = `
        <p><strong>${surah}</strong></p>
        <p>${ayahText}</p>
      `;

      resultsDiv.appendChild(ayahDiv);
    });
  } catch (err) {
    resultsDiv.innerHTML = "Error fetching ayahs: " + err.message;
  }
});
