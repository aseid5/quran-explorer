# Quran Explorer

Quran Explorer is a web-based application that allows users to search for verses from the Quran using keywords. It helps users explore ayahs that are relevant to specific topics like mercy, light, or justice.

## Features

- Search Quranic verses by keyword
- Display verse text along with the Surah name
- Simple and accessible user interface
- Responsive layout for various screen sizes

## Technologies Used

- HTML, CSS, JavaScript
- Node.js with Express
- Al-Quran Cloud API for ayah search

## Notes

This project was built to provide users with a more interactive way to navigate and explore the Quran. The Save feature and database storage were originally planned but removed to ensure functionality remained clean and bug-free during local testing.

The focus was placed on usability, design clarity, and API integration.

## Pages

- `index.html` – Home page with app introduction
- `explore.html` – Search interface for Quranic verses
- `about.html` – Overview of the app and its purpose

## Future Improvements

- Enable real-time saving of favorite ayahs to a database
- Add voice search or daily ayah feature
- Improve styling and responsiveness for mobile devices
